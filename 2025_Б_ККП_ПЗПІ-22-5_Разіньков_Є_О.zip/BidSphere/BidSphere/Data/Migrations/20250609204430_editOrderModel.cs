﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BidSphere.Migrations
{
    /// <inheritdoc />
    public partial class editOrderModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DeliveryAddress",
                table: "Orders");

            migrationBuilder.DropColumn(
                name: "ExpressPostData",
                table: "Orders");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "DeliveryAddress",
                table: "Orders",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ExpressPostData",
                table: "Orders",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
