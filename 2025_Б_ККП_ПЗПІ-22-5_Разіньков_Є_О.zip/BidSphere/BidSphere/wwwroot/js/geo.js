﻿window.getUserCoordinates = () => {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            reject("Geolocation not supported");
            return;
        }
        navigator.geolocation.getCurrentPosition(
            (position) => {
                console.log("Got position:", position);
                resolve({
                    lat: position.coords.latitude,
                    lon: position.coords.longitude
                });
            },
            (error) => {
                console.error("Geolocation error:", error);
                reject("Geolocation error: " + error.message);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    });
};
async function getUserIPCoordinates() {
    const res = await fetch("https://ipapi.co/json/");
    const data = await res.json();
    return { lat: data.latitude, lon: data.longitude };
}

function initMap(lat, lon) {
    const map = L.map('location-map').setView([lat, lon], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    L.marker([lat, lon]).addTo(map);
}