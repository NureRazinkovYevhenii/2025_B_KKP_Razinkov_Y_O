﻿using BidSphere.Data;
using Microsoft.EntityFrameworkCore;

namespace BidSphere.Service
{
    public class CategoryService
    {
        private readonly ApplicationDbContext _db;
        public CategoryService(ApplicationDbContext db) => _db = db;

        public async Task<List<Category>> GetCategoriesAsync()
            => await _db.Categories.OrderBy(c => c.Name).ToListAsync();
    }
}
