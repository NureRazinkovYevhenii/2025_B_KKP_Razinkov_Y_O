﻿using Microsoft.AspNetCore.SignalR;

namespace BidSphere.Helpers
{
    public class AuctionHub : Hub
    {
        public async Task SendBidUpdate(int auctionId)
        {
            await Clients.Group($"auction-{auctionId}").SendAsync("ReceiveBidUpdate", auctionId);
        }

        public async Task NotifyAuctionEnded(int auctionId)
        {
            await Clients.Group($"auction-{auctionId}")
                .SendAsync("AuctionEnded", auctionId);
        }

        public override async Task OnConnectedAsync()
        {
            var httpContext = Context.GetHttpContext();
            if (httpContext.Request.Query.TryGetValue("auctionId", out var auctionId))
            {
                await Groups.AddToGroupAsync(Context.ConnectionId, $"auction-{auctionId}");
            }
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            var httpContext = Context.GetHttpContext();
            if (httpContext.Request.Query.TryGetValue("auctionId", out var auctionId))
            {
                await Groups.RemoveFromGroupAsync(Context.ConnectionId, $"auction-{auctionId}");
            }
            await base.OnDisconnectedAsync(exception);
        }

    }
}
