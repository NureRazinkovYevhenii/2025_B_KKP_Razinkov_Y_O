﻿using BidSphere.Data;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace BidSphere.Service
{
    public class UserService
    {
        private readonly ApplicationDbContext _db;
        private readonly IWebHostEnvironment _env;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly AuthenticationStateProvider _authenticationStateProvider;

        public UserService(ApplicationDbContext db,IWebHostEnvironment env, AuthenticationStateProvider authenticationStateProvider, UserManager<ApplicationUser> userManager)
        {
            _db = db;
            _env = env;
            _authenticationStateProvider = authenticationStateProvider;
            _userManager = userManager;
        }
        public string GetAvatarUrl(ApplicationUser user)
        {
            return string.IsNullOrEmpty(user.AvatarFileName)
                ? "images/avatar.png"
                : $"uploads/avatars/{user.AvatarFileName}";
        }

        public async Task<ApplicationUser> GetUserWithAuctionsByIdAsync(string userId)
        {
            return await _db.Users
                .Include(u => u.Auctions)
                .FirstOrDefaultAsync(u => u.Id == userId);
        }

        public async Task<ApplicationUser> GetByIdAsync(string userId)
        {
            return await _db.Users
                .FirstOrDefaultAsync(u => u.Id == userId);
        }

        public async Task<ApplicationUser> GetCurrentUserAsync()
        {
            var authState = await _authenticationStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;

            if (user.Identity?.IsAuthenticated != true)
                return null;

            var userId = _userManager.GetUserId(user);
            if (userId == null)
                return null;

            return await _userManager.FindByIdAsync(userId);
        }

        public async Task<bool> UpdateAvatarAsync(string userId, byte[] fileData, string originalFileName)
        {
            Console.WriteLine("Updating avatar for user: " + userId);
            var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == userId);
            if (user == null)
                return false;

            try
            {
                var ext = Path.GetExtension(originalFileName);
                var fileName = $"{Guid.NewGuid()}{ext}";

                var avatarsFolder = Path.Combine(_env.WebRootPath, "uploads", "avatars");
                if (!Directory.Exists(avatarsFolder))
                {
                    Directory.CreateDirectory(avatarsFolder);
                }

                var filePath = Path.Combine(avatarsFolder, fileName);

                await File.WriteAllBytesAsync(filePath, fileData);

                if (!string.IsNullOrEmpty(user.AvatarFileName))
                {
                    var oldFilePath = Path.Combine(avatarsFolder, user.AvatarFileName);
                    if (File.Exists(oldFilePath))
                    {
                        File.Delete(oldFilePath);
                    }
                }

                user.AvatarFileName = fileName;
                _db.Users.Update(user);
                await _db.SaveChangesAsync();

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
