﻿window.auctionTimerIntervalId = window.auctionTimerIntervalId || null;
window._auctionTimerReloaded = false;

window.startAuctionTimer = function (elementId, endTimeIso) {
    if (window.auctionTimerIntervalId) {
        clearInterval(window.auctionTimerIntervalId);
    }
    window._auctionTimerReloaded = false;

    const end = new Date(endTimeIso);

    function update() {
        const now = new Date();
        let diff = end - now;
        if (diff < 0) diff = 0;

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((diff / (1000 * 60)) % 60);
        const seconds = Math.floor((diff / 1000) % 60);

        const text = diff > 0
            ? `${days}д ${hours}ч ${minutes}м ${seconds}с`
            : "Аукціон завершується";

        const el = document.getElementById(elementId);
        if (el) el.innerText = text;
    }

    update();
    window.auctionTimerIntervalId = setInterval(update, 1000);
};

window.stopAuctionTimer = function () {
    if (window.auctionTimerIntervalId) {
        clearInterval(window.auctionTimerIntervalId);
        window.auctionTimerIntervalId = null;
    }
}
window.getUserTimeZone = function () {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
}