﻿using BidSphere.Data;
using BidSphere.Data.Models;
using System.ComponentModel.DataAnnotations;

public interface IAuctionBase
{
    int Id { get; }
    string Title { get; }
    string ImageUrl { get; }
    decimal? CurrentPrice { get; }
    decimal StartPrice { get; }
    DateTime StartTime { get; }
    DateTime EndTime { get; }
}

public enum AuctionStatus
{
    Draft = 0,
    Active = 1, 
    Ended = 2,
    Cancelled = 3
}
public class Auction : IAuctionBase
{
    public int Id { get; set; }

    [Required]
    [StringLength(100, MinimumLength = 5)]
    public string Title { get; set; }

    [Required]
    [StringLength(1000)]
    public string Description { get; set; }

    [Url]
    public string? ImageUrl { get; set; }

    [Range(0.01, 1_000_000)]
    public decimal StartPrice { get; set; }

    [Range(0.01, 1_000_000)]
    public decimal? CurrentPrice { get; set; }

    [Required]
    public DateTime StartTime { get; set; }

    [Required]
    public DateTime EndTime { get; set; }

    public int? LocationId { get; set; }

    [Required]
    public AuctionStatus Status { get; set; } = AuctionStatus.Draft;

    [Required]
    public string OwnerId { get; set; }

    public ApplicationUser Owner { get; set; }

    public string? WinnerId { get; set; }
    public ApplicationUser? Winner { get; set; }

    public int? CategoryId { get; set; }
    public Category? Category { get; set; }

    [Range(0, int.MaxValue)]
    public int Views { get; set; } = 0;

    public ICollection<Bid> Bids { get; set; } = new List<Bid>();

}

public class AuctionDto : IAuctionBase
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string ImageUrl { get; set; }
    public decimal? CurrentPrice { get; set; }
    public decimal StartPrice { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
}
