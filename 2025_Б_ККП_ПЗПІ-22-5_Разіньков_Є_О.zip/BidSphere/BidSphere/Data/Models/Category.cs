﻿using System.ComponentModel.DataAnnotations;
using BidSphere.Data;

public class Category
{
    public int Id { get; set; }

    [Required]
    [StringLength(50)]
    public string Name { get; set; }

    public ICollection<Auction> Auctions { get; set; } = new List<Auction>();
}
