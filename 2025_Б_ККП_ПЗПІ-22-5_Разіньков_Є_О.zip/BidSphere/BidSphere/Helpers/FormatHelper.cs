﻿namespace BidSphere.Helpers
{
    public class FormatHelper
    {
        public static string GetRegistrationDateFormatted(DateTime? dateTime)
        {
            if (dateTime == null)
                return "невідомо";

            var created = dateTime.Value;

            if (created.Year == DateTime.UtcNow.Year)
            {
                return $"{created.Day} {GetUkrainianMonthName(created.Month)}";
            }

            return $"{created.Year}";
        }

        private static string GetUkrainianMonthName(int month)
        {
            return month switch
            {
                1 => "січня",
                2 => "лютого",
                3 => "березня",
                4 => "квітня",
                5 => "травня",
                6 => "червня",
                7 => "липня",
                8 => "серпня",
                9 => "вересня",
                10 => "жовтня",
                11 => "листопада",
                12 => "грудня",
                _ => ""
            };
        }

        public static string FormatPrice(decimal? price)
        {
            if (price == null) return "";
            return ((int)price.Value).ToString("#,0", new System.Globalization.CultureInfo("uk-UA")).Replace(",", " ");
        }

        public static string MaskUserName(string? userName)
        {
            if (string.IsNullOrEmpty(userName) || userName.Length < 3)
                return "***";
            if (userName.Length == 3)
                return $"{userName[0]}*{userName[2]}";
            return $"{userName[0]}{new string('*', userName.Length - 3)}{userName[^2]}{userName[^1]}";
        }
    }
}
