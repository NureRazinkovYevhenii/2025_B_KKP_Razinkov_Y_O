﻿using BidSphere.Data;
using BidSphere.Helpers;
using Hangfire;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;


namespace BidSphere.Service
{
    public class AuctionService
    {
        private readonly ApplicationDbContext _db;
        private readonly OrderService _orderService;
        private readonly IWebHostEnvironment _env;
        private readonly RecentlyViewedCacheService _recentlyViewedCacheService;
        private readonly Hangfire.IBackgroundJobClient BackgroundJobs;
        private readonly IHubContext<AuctionHub> _hubContext;

        public AuctionService(ApplicationDbContext db, IWebHostEnvironment env, RecentlyViewedCacheService recentlyViewedCacheService, OrderService orderService, IBackgroundJobClient backgroundJobs, IHubContext<AuctionHub> hubContext)
        {
            _db = db;
            _env = env;
            _recentlyViewedCacheService = recentlyViewedCacheService;
            _orderService = orderService;
            BackgroundJobs = backgroundJobs;
            _hubContext = hubContext;
        }

        public async Task<List<Auction>> GetAuctionsByUserIdAsync(string userId)
        {
            return await _db.Auctions
                .Where(a => a.OwnerId == userId)
                .Select(a => new Auction
                {
                    Id = a.Id,
                    Title = a.Title,
                    Description = a.Description,
                    ImageUrl = a.ImageUrl,
                    StartPrice = a.StartPrice,
                    CurrentPrice = a.CurrentPrice,
                    StartTime = a.StartTime,
                    EndTime = a.EndTime,
                    Status = a.Status,
                    OwnerId = a.OwnerId,
                    Views = a.Views
                })
                .OrderByDescending(a => a.StartTime)
                .ToListAsync();
        }

        public async Task FinishAuctionAsync(int auctionId)
        {
            var auction = await _db.Auctions
                .Include(a => a.Bids)
                .FirstOrDefaultAsync(a => a.Id == auctionId);

            if (auction == null || auction.Status != AuctionStatus.Active)
                return;

            var winningBid = auction.Bids
                .OrderByDescending(b => b.Amount)
                .FirstOrDefault();

            auction.WinnerId = winningBid?.UserId;
            auction.Status = AuctionStatus.Ended;
            auction.EndTime = DateTime.UtcNow;

            if (auction.WinnerId != null && winningBid != null)
            {
                await _orderService.CreateOrderFromAuctionAsync(
                    auctionId,
                    auction.WinnerId,
                    winningBid.Amount
                );
            }

            await _db.SaveChangesAsync();

            await _hubContext.Clients.Group($"auction-{auctionId}")
                    .SendAsync("AuctionEnded", auctionId);
        }

        public async Task<Auction> CreateAuctionAsync(Auction auction, List<byte[]> photos)
        {
            auction.EndTime = DateTime.UtcNow.AddMinutes(1);

            _db.Auctions.Add(auction);
            await _db.SaveChangesAsync();

            if (photos.Count > 0)
            {
                var uploadPath = Path.Combine(_env.WebRootPath, "uploads", auction.Id.ToString());
                Directory.CreateDirectory(uploadPath);

                string? firstImageUrl = null;
                for (int i = 0; i < photos.Count; i++)
                {
                    var fileName = $"photo{i + 1}.jpg";
                    var filePath = Path.Combine(uploadPath, fileName);
                    await File.WriteAllBytesAsync(filePath, photos[i]);
                    if (i == 0) firstImageUrl = $"/uploads/{auction.Id}/{fileName}";
                }

                if (firstImageUrl != null)
                {
                    auction.ImageUrl = firstImageUrl;
                    await _db.SaveChangesAsync();
                }
            }
            BackgroundJobs.Schedule<AuctionService>(
                service => service.FinishAuctionAsync(auction.Id),
                auction.EndTime - DateTime.UtcNow
            );

            return auction;
        }

        public async Task<Auction?> GetByIdAsync(int id)
        {
            return await _db.Auctions
                .Include(a => a.Owner)
                .Include(a => a.Winner)
                .Include(a => a.Category)
                .Include(a => a.Bids)
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task<Auction?> GetByIdFreshAsync(int id)
        {
            return await _db.Auctions
                .AsNoTracking()
                .Include(a => a.Owner)
                .Include(a => a.Winner)
                .Include(a => a.Category)
                .Include(a => a.Bids)
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task<List<Auction>> GetAuctionsAsync(
            Func<IQueryable<Auction>, IQueryable<Auction>> queryFunc = null,
            int? take = null)
        {
            IQueryable<Auction> query = _db.Auctions;

            if (queryFunc != null)
                query = queryFunc(query);

            if (take.HasValue)
                query = query.Take(take.Value);

            return await query.ToListAsync();
        }



        public async Task<List<IAuctionBase>> SearchAuctionsAsync(
    string? searchTerm,
    int? categoryId,
    string? status,
    decimal? minPrice,
    decimal? maxPrice,
    int? locationId = null) // добавляем LocationId как фильтр
        {
            var query = _db.Auctions.AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
                query = query.Where(a => a.Title.Contains(searchTerm) || a.Description.Contains(searchTerm));

            if (categoryId.HasValue)
                query = query.Where(a => a.CategoryId == categoryId);

            if (!string.IsNullOrWhiteSpace(status))
            {
                if (status == "Active")
                    query = query.Where(a => a.EndTime > DateTime.UtcNow);
                else if (status == "Completed")
                    query = query.Where(a => a.EndTime <= DateTime.UtcNow);
            }

            if (minPrice.HasValue)
                query = query.Where(a => a.CurrentPrice >= minPrice);

            if (maxPrice.HasValue)
                query = query.Where(a => a.CurrentPrice <= maxPrice);

            // Фильтр по LocationId
            if (locationId.HasValue)
                query = query.Where(a => a.LocationId == locationId.Value);

            var auctions = await query
                .OrderByDescending(a => a.StartTime)
                .Select(a => new AuctionDto
                {
                    Id = a.Id,
                    Title = a.Title,
                    ImageUrl = a.ImageUrl,
                    CurrentPrice = a.CurrentPrice,
                    StartPrice = a.StartPrice,
                    StartTime = a.StartTime,
                    EndTime = a.EndTime
                })
                .ToListAsync();

            return auctions.Cast<IAuctionBase>().ToList();
        }

        public async Task UpdateAsync(Auction auction)
        {
            _db.Auctions.Update(auction);
            await _db.SaveChangesAsync();
        }

        public async Task<bool> UpdateViewsAsync(int auctionId, string userId)
        {
            if(string.IsNullOrEmpty(userId))
                return false;

            var recentlyViewedIds = _recentlyViewedCacheService.GetSortedAuctionIds(userId);

            if (!recentlyViewedIds.Contains(auctionId))
            {
                var auction = await _db.Auctions.FirstOrDefaultAsync(a => a.Id == auctionId);
                if (auction == null)
                    return false;

                auction.Views += 1;
                await _db.SaveChangesAsync();

                _recentlyViewedCacheService.AddOrUpdateViewedAuction(userId, auctionId);
                return true;
            }
            else
            {
                _recentlyViewedCacheService.AddOrUpdateViewedAuction(userId, auctionId);
                return false;
            }
        }

        public List<string> GetAuctionPhotoUrls(int auctionId)
        {
            var photoDir = Path.Combine(_env.WebRootPath, "uploads", auctionId.ToString());

            if (Directory.Exists(photoDir))
            {
                return Directory.GetFiles(photoDir)
                    .Select(f => $"/uploads/{auctionId}/{Path.GetFileName(f)}")
                    .ToList();
            }

            return new List<string> { "/images/no-image.png" };
        }
    }
}
