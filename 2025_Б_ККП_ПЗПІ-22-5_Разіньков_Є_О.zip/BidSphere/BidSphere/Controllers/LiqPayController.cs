﻿using BidSphere.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Text.Json;

namespace BidSphere.Controllers
{
    [ApiController]
    [Route("api/liqpay")]
    public class LiqPayController : ControllerBase
    {
        private readonly ApplicationDbContext _db;

        public LiqPayController(ApplicationDbContext db)
        {
            _db = db;
        }

        [HttpGet("test")]
        public IActionResult Test()
        {
            return Ok("LiqPay controller is working!");
        }

        [HttpPost("callback")]
        public async Task<IActionResult> Callback([FromForm] string data, [FromForm] string signature)
        {
            if (string.IsNullOrEmpty(data))
                return BadRequest();

            var json = Encoding.UTF8.GetString(Convert.FromBase64String(data));
            var paymentInfo = JsonSerializer.Deserialize<LiqPayCallbackModel>(json);

            if (paymentInfo == null || string.IsNullOrEmpty(paymentInfo.order_id))
                return BadRequest();

            if (!int.TryParse(paymentInfo.order_id, out int orderId))
                return BadRequest();

            var order = await _db.Orders.FirstOrDefaultAsync(o => o.Id == orderId);

            if (order == null)
                return NotFound();

            order.PaymentId = paymentInfo.payment_id;
            order.PaymentStatus = paymentInfo.status;

            if (paymentInfo.status == "success" || paymentInfo.status == "sandbox")
            {
                order.Status = OrderStatus.Paid;
                order.PaidAt = DateTime.UtcNow;
            }

            await _db.SaveChangesAsync();

            return Ok();
        }
    }

    public class LiqPayCallbackModel
    {
        public string status { get; set; }
        public string order_id { get; set; }
        public long? payment_id { get; set; }
    }
}
