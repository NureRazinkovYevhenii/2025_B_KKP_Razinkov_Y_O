﻿using BidSphere.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MimeKit;
using MailKit.Net.Smtp;
using MailKit.Security;

namespace BidSphere.Service
{
    public class SmtpEmailSender : IEmailSender<ApplicationUser>
    {
        private readonly IConfiguration _config;
        private readonly ILogger<SmtpEmailSender> _logger;

        public SmtpEmailSender(IConfiguration config, ILogger<SmtpEmailSender> logger)
        {
            _config = config;
            _logger = logger;
        }

        public async Task SendConfirmationLinkAsync(ApplicationUser user, string email, string confirmationLink)
        {
            var subject = "Confirm your BidSphere account";
            var body = $"Click this link to confirm your account: {confirmationLink}";
            await SendEmailAsync(email, subject, body, isHtml: false);
        }

        public async Task SendPasswordResetCodeAsync(ApplicationUser user, string email, string code)
        {
            var subject = "Reset Password Code";
            var body = $"Your reset code is: {code}";
            await SendEmailAsync(email, subject, body, isHtml: false);
        }

        public async Task SendPasswordResetLinkAsync(ApplicationUser user, string email, string link)
        {
            var subject = "Reset Password Link";
            var body = $"Reset your password by clicking here: <a href=\"{link}\">{link}</a>";
            await SendEmailAsync(email, subject, body, isHtml: true);
        }

        private async Task SendEmailAsync(string toEmail, string subject, string messageBody, bool isHtml)
        {
            var smtp = _config.GetSection("Smtp");

            var message = new MimeMessage();
            message.From.Add(MailboxAddress.Parse(smtp["From"]));
            message.To.Add(MailboxAddress.Parse(toEmail));
            message.Subject = subject;

            var bodyBuilder = new BodyBuilder();
            if (isHtml)
            {
                bodyBuilder.HtmlBody = messageBody;
            }
            else
            {
                bodyBuilder.TextBody = messageBody;
            }
            message.Body = bodyBuilder.ToMessageBody();

            using var client = new SmtpClient();
            await client.ConnectAsync(smtp["Host"], int.Parse(smtp["Port"]), SecureSocketOptions.StartTls);
            await client.AuthenticateAsync(smtp["Username"], smtp["Password"]);
            await client.SendAsync(message);
            await client.DisconnectAsync(true);

            _logger.LogInformation("Email sent to {Email} with subject {Subject}", toEmail, subject);
        }
    }
}
