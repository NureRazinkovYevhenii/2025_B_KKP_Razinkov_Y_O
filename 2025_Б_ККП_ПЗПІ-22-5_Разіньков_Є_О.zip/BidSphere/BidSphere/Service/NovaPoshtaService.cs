﻿using System.Net.Http;
using System.Text.Json;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace BidSphere.Service
{
    public class NovaPoshtaService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey = "3e257fb5e4831e09f91decfd958e4fd7";

        public NovaPoshtaService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        private async Task<List<T>> PostWithApiKeyAsync<T>(object requestBody)
        {
            var requestWithKey = new Dictionary<string, object>();
            foreach (var prop in requestBody.GetType().GetProperties())
            {
                requestWithKey[prop.Name] = prop.GetValue(requestBody);
            }
            requestWithKey["apiKey"] = _apiKey;

            var requestJson = JsonSerializer.Serialize(requestWithKey);
            var requestContent = new StringContent(requestJson, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(
                "https://api.novaposhta.ua/v2.0/json/",
                requestContent
            );

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new HttpRequestException($"NovaPoshta API error: {response.StatusCode}, {error}");
            }

            var json = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<NpResponse<T>>(json);

            if (result == null || result.data == null)
                throw new HttpRequestException("Invalid response from NovaPoshta API");

            return result.data;
        }

        public async Task<List<AreaDto>> GetAreasAsync()
        {
            var request = new
            {
                modelName = "Address",
                calledMethod = "getAreas",
                methodProperties = new { }
            };

            return await PostWithApiKeyAsync<AreaDto>(request);
        }

        public async Task<List<CityDto>> GetCitiesByAreaRefAsync(string areaRef)
        {
            var request = new
            {
                modelName = "Address",
                calledMethod = "getCities",
                methodProperties = new { AreaRef = areaRef }
            };

            return await PostWithApiKeyAsync<CityDto>(request);
        }

        public async Task<List<CityDto>> GetCitiesByStringAsync(string searchString)
        {
            var request = new
            {
                modelName = "Address",
                calledMethod = "getCities",
                methodProperties = new { FindByString = searchString }
            };

            return await PostWithApiKeyAsync<CityDto>(request);
        }

        public async Task<List<WarehouseDto>> GetWarehousesByCityRefAsync(string cityRef)
        {
            var request = new
            {
                modelName = "Address",
                calledMethod = "getWarehouses",
                methodProperties = new { CityRef = cityRef }
            };

            return await PostWithApiKeyAsync<WarehouseDto>(request);
        }


        public async Task<NovaPoshtaVerifyResult> VerifyShippingAsync(string trackingNumber, string phone, Order order)
        {
            var request = new
            {
                modelName = "TrackingDocument",
                calledMethod = "getStatusDocuments",
                methodProperties = new
                {
                    Documents = new[]
                    {
                new { DocumentNumber = trackingNumber, Phone = phone }
            }
                }
            };

            var response = await PostWithApiKeyAsync<NpTrackingResponse>(request);

            if (response == null || response.Count == 0)
                return new NovaPoshtaVerifyResult { IsSuccess = false, Message = "Нічого не знайдено по ТТН" };

            var doc = response[0];

            // Сверка ФИО (ПІБ)
            bool fioMatch = !string.IsNullOrEmpty(order.RecipientFullName) &&
                doc.RecipientFullName?.Trim().ToLower().Contains(order.RecipientFullName.Trim().ToLower()) == true;

            // Сверка телефона (можно сравнивать только последние 7-9 цифр, если нужно)
            string orderPhone = order.RecipientPhone?.Replace("+", "").Replace(" ", "").Replace("-", "");
            string docPhone = doc.PhoneRecipient?.Replace("+", "").Replace(" ", "").Replace("-", "");
            bool phoneMatch = !string.IsNullOrEmpty(orderPhone) && !string.IsNullOrEmpty(docPhone) &&
                (orderPhone.EndsWith(docPhone) || docPhone.EndsWith(orderPhone));

            // Сверка отделения (по номеру или по строке)
            bool warehouseMatch = false;
            if (!string.IsNullOrEmpty(order.RecipientWarehouse) && !string.IsNullOrEmpty(doc.WarehouseRecipient))
            {
                // Можно сравнивать по номеру отделения, если он есть в строке
                var orderWarehouseNum = new string(order.RecipientWarehouse.Where(char.IsDigit).ToArray());
                var docWarehouseNum = new string(doc.WarehouseRecipient.Where(char.IsDigit).ToArray());
                warehouseMatch = !string.IsNullOrEmpty(orderWarehouseNum) && !string.IsNullOrEmpty(docWarehouseNum)
                    ? orderWarehouseNum == docWarehouseNum
                    : doc.WarehouseRecipient.Contains(order.RecipientWarehouse, StringComparison.OrdinalIgnoreCase);
            }

            if (fioMatch && phoneMatch && warehouseMatch)
                return new NovaPoshtaVerifyResult { IsSuccess = true, Message = "Дані співпадають" };

            // Для отладки можно вернуть, что именно не совпало
            var errors = new List<string>();
            if (!fioMatch) errors.Add("ПІБ не співпадає");
            if (!phoneMatch) errors.Add("Телефон не співпадає");
            if (!warehouseMatch) errors.Add("Відділення не співпадає");

            return new NovaPoshtaVerifyResult
            {
                IsSuccess = false,
                Message = "Дані не співпадають: " + string.Join(", ", errors)
            };
        }

        public async Task<NovaPoshtaDeliveryStatus> GetDeliveryStatusAsync(string trackingNumber, string phone)
        {
            var request = new
            {
                modelName = "TrackingDocument",
                calledMethod = "getStatusDocuments",
                methodProperties = new
                {
                    Documents = new[]
                    {
                new { DocumentNumber = trackingNumber, Phone = phone }
            }
                }
            };

            var response = await PostWithApiKeyAsync<NovaPoshtaDeliveryStatus>(request);

            if (response == null || response.Count == 0)
                return null;

            return response[0];
        }
    }
    public class NovaPoshtaVerifyResult
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }

    public class NpResponse<T>
    {
        public List<T> data { get; set; }
    }


    public class NovaPoshtaDeliveryStatus
    {
        public string StatusCode { get; set; }
        public string Status { get; set; }
        public string RecipientDateTime { get; set; }
        public string ActualDeliveryDate { get; set; }
        public object Redelivery { get; set; }
        public string RedeliveryNum { get; set; }
        // ... другие нужные поля
    }

    public class NpTrackingResponse
    {
        public string RecipientFullName { get; set; }
        public string RecipientCityName { get; set; }
        public string PhoneRecipient { get; set; }
        public string WarehouseRecipient { get; set; }
        // ... другие нужные поля
    }
    public class AreaDto
    {
        public string Ref { get; set; }
        public string Description { get; set; }
    }

    public class CityDto
    {
        public string Ref { get; set; }
        public string Description { get; set; }
        public string Area { get; set; }
    }

    public class WarehouseDto
    {
        public string Ref { get; set; }
        public string Description { get; set; }
        public string CityRef { get; set; }
    }
}