﻿using BidSphere.Data;
using BidSphere.Service;
using Hangfire;
using Microsoft.EntityFrameworkCore;

namespace BidSphere.Service
{
    public class BackgroundJobService
    {
        private readonly IServiceProvider _serviceProvider;

        public BackgroundJobService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public async Task CheckAllDeliveriesAsync()
        {
            using (var scope = _serviceProvider.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                var orderService = scope.ServiceProvider.GetRequiredService<OrderService>();
                var novaPoshtaService = scope.ServiceProvider.GetRequiredService<NovaPoshtaService>();

                Console.WriteLine($"Checked shipped and delivered orders for delivery status.");
                try
                {
                    var ordersToCheck = await db.Orders
                        .Where(o =>
                            (o.Status == OrderStatus.Shipped || o.Status == OrderStatus.Delivered)
                            && !string.IsNullOrEmpty(o.TrackingNumber))
                        .ToListAsync();

                    foreach (var order in ordersToCheck)
                    {
                        var status = await novaPoshtaService.GetDeliveryStatusAsync(order.TrackingNumber, order.RecipientPhone);

                        if (status == null)
                            continue;

                        if (status.StatusCode == "9" || status.Status?.Contains("отримано", StringComparison.OrdinalIgnoreCase) == true)
                        {

                            await orderService.CompleteOrderAsync(order.Id);
                        }
                        else if ((order.Status == OrderStatus.Shipped) &&
                                 (status.StatusCode == "8" || status.Status?.Contains("доставлено на відділення", StringComparison.OrdinalIgnoreCase) == true))
                        {
                            order.Status = OrderStatus.Delivered;
                            order.DeliveredAt = DateTime.UtcNow;
                        }
                        else if (status.Status?.Contains("повернуто відправнику", StringComparison.OrdinalIgnoreCase) == true)
                        {
                            order.Status = OrderStatus.Cancelled;
                            await orderService.CancelOrderAsync(order.Id);
                        }
                    }

                    await db.SaveChangesAsync();

                    Console.WriteLine($"Checked {ordersToCheck.Count} shipped and delivered orders for delivery status.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("CheckAllDeliveriesAsync ERROR: " + ex);
                }
                finally
                {
                    BackgroundJob.Schedule<BackgroundJobService>(
                        job => job.CheckAllDeliveriesAsync(),
                        TimeSpan.FromHours(6)
                    );
                }
            }
        }
    }
}