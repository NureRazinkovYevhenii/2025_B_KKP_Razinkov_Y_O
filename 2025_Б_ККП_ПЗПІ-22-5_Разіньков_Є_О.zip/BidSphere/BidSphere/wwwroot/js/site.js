﻿window.scrollCarousel = (id, direction) => {
    const el = document.getElementById(id);
    if (!el) return;
    const card = el.querySelector('.auction-card');
    const gap = 24; // px, как в gap: 1.5rem
    const scrollAmount = card ? card.offsetWidth + gap : 300;
    el.scrollBy({ left: direction * scrollAmount, behavior: 'smooth' });
};

window.submitLiqPayForm = function (data, signature) {
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = 'https://www.liqpay.ua/api/3/checkout';
    form.acceptCharset = 'utf-8';

    var inputData = document.createElement('input');
    inputData.type = 'hidden';
    inputData.name = 'data';
    inputData.value = data;
    form.appendChild(inputData);

    var inputSignature = document.createElement('input');
    inputSignature.type = 'hidden';
    inputSignature.name = 'signature';
    inputSignature.value = signature;
    form.appendChild(inputSignature);

    document.body.appendChild(form);
    form.submit();
};
