﻿using Microsoft.Extensions.Caching.Memory;

public class RecentlyViewedCacheService
{
    private readonly IMemoryCache _cache;
    private readonly TimeSpan _cacheDuration = TimeSpan.FromDays(7);

    public RecentlyViewedCacheService(IMemoryCache cache)
    {
        _cache = cache;
    }

    private string GetCacheKey(string userId) => $"recently_viewed_{userId}";

    public Dictionary<int, DateTime> GetRecentlyViewed(string userId)
    {
        if (_cache.TryGetValue(GetCacheKey(userId), out Dictionary<int, DateTime> dict))
        {
            return dict;
        }
        return new Dictionary<int, DateTime>();
    }

    public void AddOrUpdateViewedAuction(string userId, int auctionId)
    {
        var dict = GetRecentlyViewed(userId);

        dict[auctionId] = DateTime.UtcNow;

        if (dict.Count > 20)
        {
            var oldest = dict.OrderBy(kv => kv.Value).First().Key;
            dict.Remove(oldest);
        }

        _cache.Set(GetCacheKey(userId), dict, _cacheDuration);
    }

    public List<int> GetSortedAuctionIds(string userId)
    {
        var dict = GetRecentlyViewed(userId);
        return dict.OrderByDescending(kv => kv.Value).Select(kv => kv.Key).ToList();
    }
}