using BidSphere.Data.Models;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace BidSphere.Data
{
    public class ApplicationUser : IdentityUser
    {
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Range(0, 100)]
        public int Rating { get; set; } = 100;

        [MaxLength(255)]
        public string? AvatarFileName { get; set; }

        public ICollection<Auction> Auctions { get; set; } = new List<Auction>();
        public ICollection<Bid> Bids { get; set; } = new List<Bid>();
        public ICollection<Order> Orders { get; set; } = new List<Order>();
    }

}
