﻿using BidSphere.Data;
using BidSphere.Service;
using Hangfire;
using MailKit.Search;
using Microsoft.EntityFrameworkCore;
using static BidSphere.Components.Pages.ProfilePage;

public class OrderService
{
    private readonly ApplicationDbContext _db;
    private readonly IServiceProvider _serviceProvider;
    private readonly NovaPoshtaService _novaPoshtaService;
    private readonly LiqPayService _liqPayService;

    public OrderService(ApplicationDbContext db, IServiceProvider serviceProvider, NovaPoshtaService novaPoshtaService, LiqPayService liqPayService)
    {
        _db = db;
        _serviceProvider = serviceProvider;
        _novaPoshtaService = novaPoshtaService;
        _liqPayService = liqPayService;
    }
    public async Task<Order> CreateOrderFromAuctionAsync(int auctionId, string winnerId, decimal amount)
    {
        var order = new Order
        {
            AuctionId = auctionId,
            BuyerId = winnerId,
            Amount = amount,
            Status = OrderStatus.WaitingPayment,
            CreatedAt = DateTime.UtcNow
        };

        _db.Orders.Add(order);
        await _db.SaveChangesAsync();

        return order;
    }
    public async Task<bool> UpdateTrackingNumberAsync(int orderId, string? trackingNumber)
    {
        var order = await _db.Orders.FindAsync(orderId);
        if (order == null)
            throw new Exception("Order not found");

        var buyerPhone = order.RecipientPhone;
        if (string.IsNullOrEmpty(buyerPhone))
            throw new Exception("No buyer phone");

        var verifyResult = await _novaPoshtaService.VerifyShippingAsync(trackingNumber, buyerPhone, order);

        if (!verifyResult.IsSuccess)
            return false;

        order.TrackingNumber = trackingNumber;
        order.Status = OrderStatus.Shipped;
        order.ShippedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        return true;
    }
    public async Task UpdateRecipientDataAsync(
    int orderId,
    string region,
    string city,
    string warehouse,
    string fullName,
    string phone)
    {
        var order = await _db.Orders.FindAsync(orderId);
        if (order == null) throw new Exception("Order not found");

        order.RecipientRegion = region;
        order.RecipientCity = city;
        order.RecipientWarehouse = warehouse;
        order.RecipientFullName = fullName;
        order.RecipientPhone = phone;

        await _db.SaveChangesAsync();
    }

    public async Task<List<Order>> GetOrdersByBuyerIdAsync(string buyerId)
    {
        return await _db.Orders
            .Where(o => o.BuyerId == buyerId)
            .Include(o => o.Auction)
            .Include(o => o.Buyer)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }
    public async Task<Order> GetOrderByIdAsync(int orderId)
    {
        return await _db.Orders
            .Include(o => o.Auction)
            .Include(o => o.Buyer)
            .FirstOrDefaultAsync(o => o.Id == orderId);
    }

    public async Task<List<Order>> GetOrdersBySellerIdAsync(string sellerId)
    {
        return await _db.Orders
            .Where(o => o.Auction.OwnerId == sellerId)
            .Include(o => o.Auction)
            .Include(o => o.Buyer)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }

    public async Task<bool> UpdateOrderAsync(Order updatedOrder)
    {
        var existingOrder = await _db.Orders.FindAsync(updatedOrder.Id);
        if (existingOrder == null)
            throw new Exception("Order not found");

        existingOrder.AuctionId = updatedOrder.AuctionId;
        existingOrder.BuyerId = updatedOrder.BuyerId;
        existingOrder.Amount = updatedOrder.Amount;
        existingOrder.Status = updatedOrder.Status;
        existingOrder.RecipientFullName = updatedOrder.RecipientFullName;
        existingOrder.RecipientRegion = updatedOrder.RecipientRegion;
        existingOrder.RecipientCity = updatedOrder.RecipientCity;
        existingOrder.RecipientWarehouse = updatedOrder.RecipientWarehouse;
        existingOrder.RecipientPhone = updatedOrder.RecipientPhone;
        existingOrder.TrackingNumber = updatedOrder.TrackingNumber;
        existingOrder.PayoutCard = updatedOrder.PayoutCard;
        existingOrder.PaidAt = updatedOrder.PaidAt;
        existingOrder.ShippedAt = updatedOrder.ShippedAt;
        existingOrder.DeliveredAt = updatedOrder.DeliveredAt;
        // ... добавь другие поля, которые хочешь обновлять

        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> CompleteOrderAsync(int orderId)
    {
        var order = await _db.Orders.FindAsync(orderId);
        if (order == null)
            throw new Exception("Order not found");
        var transferResult = await _liqPayService.PayoutToSellerAsync(order);

        if (!transferResult.IsSuccess)
            throw new Exception("Не вдалося перевести кошти продавцю: " + transferResult.Message);

        if(transferResult.IsSuccess)
            Console.WriteLine("Виплатили кошти продавцю: " + transferResult.Message);

        order.Status = OrderStatus.Completed;
        order.DeliveredAt = DateTime.UtcNow;

        await _db.SaveChangesAsync();

        return true;
    }

    public async Task<bool> CancelOrderAsync(int orderId)
    {
        var order = await _db.Orders.FindAsync(orderId);
        if (order == null)
            throw new Exception("Order not found");

        if (order.Status == OrderStatus.Completed || order.Status == OrderStatus.Cancelled)
            throw new Exception("Order is already completed or cancelled");

        if (order.Status == OrderStatus.Paid || order.Status == OrderStatus.Delivered)
        {
            var refundResult = await _liqPayService.RefundToBuyerAsync(order);

            if (!refundResult.IsSuccess)
                throw new Exception("Не вдалося повернути кошти покупцю: " + refundResult.Message);
        }

        order.Status = OrderStatus.Cancelled;
        await _db.SaveChangesAsync();
        return true;
    }
}