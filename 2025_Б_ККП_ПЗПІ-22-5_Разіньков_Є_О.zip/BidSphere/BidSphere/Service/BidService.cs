﻿using BidSphere.Data;
using BidSphere.Helpers;
using BidSphere.Service;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

namespace BidSphere.Service
{
    public class BidResult
    {
        public bool Success { get; set; }
        public string? Error { get; set; }
        public Bid? Bid { get; set; }
    }

    public class BidService
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly AuctionService _auctionService;
        private readonly IHubContext<AuctionHub> _hubContext;  // Добавлено

        public BidService(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            AuctionService auctionService,
            IHubContext<AuctionHub> hubContext)  // Добавлено
        {
            _context = context;
            _userManager = userManager;
            _auctionService = auctionService;
            _hubContext = hubContext;  // Добавлено
        }

        public static decimal GetMinBidIncrement(decimal? currentPrice)
        {
            if (currentPrice < 100) return 1;
            if (currentPrice < 500) return 5;
            if (currentPrice < 1000) return 10;
            if (currentPrice < 5000) return 50;
            if (currentPrice < 10000) return 100;
            return 250;
        }

        public async Task<List<Bid>> GetBidsByUserIdAsync(string userId)
        {
            return await _context.Bids
                .Where(b => b.UserId == userId)
                .Include(b => b.Auction)
                .OrderByDescending(b => b.PlacedAt)
                .ToListAsync();
        }

        public async Task<BidResult> PlaceBidAsync(int auctionId, decimal amount, string userId)
        {
            var auction = await _auctionService.GetByIdAsync(auctionId);
            if (auction == null || auction.Status != AuctionStatus.Active || DateTime.UtcNow > auction.EndTime)
            {
                return new BidResult { Success = false, Error = "Аукціон завершено або неактивний." };
            }

            var minBid = (auction.CurrentPrice) + GetMinBidIncrement(auction.CurrentPrice);
            if (amount < minBid)
            {
                return new BidResult { Success = false, Error = $"Мінімальна ставка: {minBid?.ToString("C")}" };
            }
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return new BidResult { Success = false, Error = "Користувач не знайдений." };
            }
            var bid = new Bid
            {
                AuctionId = auctionId,
                UserId = userId,
                Amount = amount,
                PlacedAt = DateTime.UtcNow
            };
            _context.Bids.Add(bid);
            auction.CurrentPrice = amount;

            await _context.SaveChangesAsync();

            var bidDtos = auction.Bids
                .OrderByDescending(b => b.PlacedAt)
                .Select(b => new BidDto
                {
                    Amount = b.Amount,
                    PlacedAt = b.PlacedAt,
                    UserName = b.User?.UserName ?? "Невідомий"
                }).ToList();

            await _hubContext.Clients
                     .Group($"auction-{auctionId}")
                     .SendAsync("ReceiveBidUpdate", auctionId, auction.CurrentPrice, bidDtos);

            return new BidResult { Success = true, Bid = bid };
        }
    }
}