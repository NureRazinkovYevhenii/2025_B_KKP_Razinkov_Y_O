﻿namespace BidSphere.Service
{
    using System;
    using System.Net.Http;
    using System.Security.Cryptography;
    using System.Text;
    using System.Text.Json;

    public class LiqPayService
    {
        private readonly string _publicKey;
        private readonly string _privateKey;
        private readonly HttpClient _httpClient;

        public LiqPayService(HttpClient httpClient)
        {
            _publicKey = "sandbox_i85400999133";
            _privateKey = "sandbox_rdSNMoTI1ZDWvrwyxJ0WoVppENyImWCWJGNRAsrG";
            _httpClient = httpClient;
        }

        public (string data, string signature) GeneratePaymentData(
    decimal amount,
    string orderId,
    string description,
    string resultUrl,
    string serverUrl)
        {
            var payment = new
            {
                public_key = _publicKey,
                version = 3,
                action = "pay",
                amount = amount,
                currency = "UAH",
                description = description,
                order_id = orderId,
                result_url = resultUrl,
                server_url = serverUrl
            };

            string json = JsonSerializer.Serialize(payment);
            string data = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
            string signature = GetSignature(data);

            return (data, signature);
        }

        private string GetSignature(string data)
        {
            string signString = _privateKey + data + _privateKey;
            using var sha1 = SHA1.Create();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(signString));
            return Convert.ToBase64String(hash);
        }

        public async Task<LiqPayResult> RefundToBuyerAsync(Order order)
        {
            var refund = new
            {
                public_key = _publicKey,
                version = 3,
                action = "refund",
                order_id = $"{order.Id}_refund",
                amount = order.Amount,
                payment_id = order.PaymentId,
                description = "Повернення коштів BidSphere"
            };

            string json = JsonSerializer.Serialize(refund);
            string data = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
            string signature = GetSignature(data);

            var content = new FormUrlEncodedContent(new[]
            {
            new KeyValuePair<string, string>("data", data),
            new KeyValuePair<string, string>("signature", signature)
        });

            var response = await _httpClient.PostAsync("https://www.liqpay.ua/api/request", content);
            var responseString = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                return new LiqPayResult { IsSuccess = true, Message = "Refund success" };
            }
            else
            {
                return new LiqPayResult { IsSuccess = false, Message = responseString };
            }
        }

        public async Task<LiqPayResult> PayoutToSellerAsync(Order order)
        {
            var payout = new
            {
                public_key = _publicKey,
                version = 3,
                action = "p2p",
                amount = (double)order.Amount,
                currency = "UAH",
                description = "Виплата за аукціон",
                order_id = $"BidSphere виплата замовлення {order.Id}",
                card = "4242424242424242",
                card_exp_month = "12",
                card_exp_year = "25",
                card_cvv = "111",
                receiver_card = order.PayoutCard
            };

            string json = JsonSerializer.Serialize(payout);
            string data = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
            string signature = GetSignature(data);

            var content = new FormUrlEncodedContent(new[]
            {
        new KeyValuePair<string, string>("data", data),
        new KeyValuePair<string, string>("signature", signature)
    });

            var response = await _httpClient.PostAsync("https://www.liqpay.ua/api/request", content);
            var responseString = await response.Content.ReadAsStringAsync();

            try
            {
                using var doc = JsonDocument.Parse(responseString);
                var root = doc.RootElement;
                var status = root.GetProperty("status").GetString();

                if (status == "success" || status == "processing" || status == "wait_accept" || status == "sandbox")
                {
                    return new LiqPayResult { IsSuccess = true, Message = $"Payout status: {status}" };
                }
                else
                {
                    var err = root.TryGetProperty("err_description", out var errDesc) ? errDesc.GetString() : responseString;
                    return new LiqPayResult { IsSuccess = false, Message = $"LiqPay error: {err}" };
                }
            }
            catch
            {
                return new LiqPayResult { IsSuccess = false, Message = responseString };
            }
        }
    }
    public class LiqPayResult
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }
}
