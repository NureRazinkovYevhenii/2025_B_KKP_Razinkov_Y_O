﻿using BidSphere.Data.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.GeoJsonObjectModel;
using System.Text.RegularExpressions;

namespace BidSphere.Service
{
    public class LocationService
    {
        private readonly IMongoCollection<Location> _locations;

        public LocationService(IConfiguration config)
        {
            var client = new MongoClient(config.GetConnectionString("MongoDb"));
            var database = client.GetDatabase("BidSphere");
            _locations = database.GetCollection<Location>("locations");
        }

        public async Task<List<Location>> AutocompleteAsync(string search, int limit = 10)
        {
            var exactFilter = Builders<Location>.Filter.Eq("name", search);
            var regexStarts = new MongoDB.Bson.BsonRegularExpression($"^{Regex.Escape(search)}", "i");
            var regexContains = new MongoDB.Bson.BsonRegularExpression(Regex.Escape(search), "i");

            var exactMatches = await _locations.Find(exactFilter).ToListAsync();

            if (exactMatches.Count > limit)
                return exactMatches.Take(limit).ToList();

            var startsFilter = Builders<Location>.Filter.Regex("name", regexStarts);
            var startsResults = await _locations.Find(startsFilter).Limit(limit).ToListAsync();

            var exactIds = exactMatches.Select(x => x.Id).ToHashSet();
            var filteredStarts = startsResults.Where(x => !exactIds.Contains(x.Id)).ToList();

            var containsFilter = Builders<Location>.Filter.Regex("name", regexContains);
            var containsResults = await _locations.Find(containsFilter).Limit(100).ToListAsync();

            var startsIds = filteredStarts.Select(x => x.Id).ToHashSet();
            var filteredContains = containsResults
                .Where(x => !exactIds.Contains(x.Id) && !startsIds.Contains(x.Id))
                .Take(limit)
                .ToList();

            var result = new List<Location>();
            result.AddRange(exactMatches);
            result.AddRange(filteredStarts);
            result.AddRange(filteredContains);

            return result.Take(limit).ToList();
        }

        public async Task<List<Location>> FindInRadiusAsync(double lat, double lng, double radiusMeters)
        {
            var point = new GeoJsonPoint<GeoJson2DGeographicCoordinates>(new GeoJson2DGeographicCoordinates(lng, lat));
            var filter = Builders<Location>.Filter.NearSphere(x => x.LocationPoint, point, radiusMeters);
            return await _locations.Find(filter).ToListAsync();
        }

        public async Task<Location?> GetByIdAsync(int? id)
        {
            if (id == null || id <= 0)
                return null;
            return await _locations.Find(l => l.Id == id).FirstOrDefaultAsync();
        }

        public async Task<int?> GetDistanceInKmAsync(int? locationId, double userLat, double userLon)
        {
            var location = await GetByIdAsync(locationId);
            if (location == null) return null;

            var userPoint = new GeoJsonPoint<GeoJson2DGeographicCoordinates>(
                new GeoJson2DGeographicCoordinates(userLon, userLat));

            var pipeline = new[]
            {
        new BsonDocument("$geoNear", new BsonDocument
        {
            { "near", new BsonDocument
                {
                    { "type", "Point" },
                    { "coordinates", new BsonArray { userLon, userLat } }
                }
            },
            { "distanceField", "distance" },
            { "spherical", true },
            { "query", new BsonDocument("id", locationId) }
        })
    };

            var result = await _locations.AggregateAsync<BsonDocument>(pipeline);
            var doc = await result.FirstOrDefaultAsync();
            if (doc != null && doc.TryGetValue("distance", out var dist))
            {
                return (int)(dist.ToDouble() / 1000);
            }
            return null;
        }
    }
}
