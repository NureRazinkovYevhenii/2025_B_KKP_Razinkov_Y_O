﻿using System.ComponentModel.DataAnnotations;
using BidSphere.Data;

public class Order
{
    public int Id { get; set; }
    public int AuctionId { get; set; }
    public Auction Auction { get; set; }

    public string BuyerId { get; set; }
    public ApplicationUser Buyer { get; set; }

    public decimal Amount { get; set; }
    public OrderStatus Status { get; set; }

    public long? PaymentId { get; set; }
    public string? PaymentStatus { get; set; }
    public string? PayoutCard { get; set; }
    public string? TrackingNumber { get; set; }

    public DateTime CreatedAt { get; set; }
    public DateTime? PaidAt { get; set; }
    public DateTime? ShippedAt { get; set; }
    public DateTime? DeliveredAt { get; set; }

    [MaxLength(100)]
    public string? RecipientRegion { get; set; }

    [MaxLength(100)]
    public string? RecipientCity { get; set; }

    [MaxLength(200)]
    public string? RecipientWarehouse { get; set; }

    [MaxLength(100)]
    public string? RecipientFullName { get; set; } // ФИО

    [MaxLength(20)]
    public string? RecipientPhone { get; set; } // Телефон
}

public enum OrderStatus
{
    WaitingPayment,
    Completed,
    Paid,
    Shipped,
    Delivered,
    Cancelled,
    Refunded
}