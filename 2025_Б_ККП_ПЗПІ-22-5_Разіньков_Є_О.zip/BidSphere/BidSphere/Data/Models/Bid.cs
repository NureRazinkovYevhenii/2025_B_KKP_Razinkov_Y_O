﻿using System.ComponentModel.DataAnnotations;
using BidSphere.Data;

public class Bid
{
    public int Id { get; set; }

    [Required]
    public int AuctionId { get; set; }
    public Auction Auction { get; set; }

    [Required]
    public string UserId { get; set; }
    public ApplicationUser User { get; set; }

    [Range(0.01, 1_000_000)]
    public decimal Amount { get; set; }

    public DateTime PlacedAt { get; set; } = DateTime.UtcNow;

}
public class BidDto
{
    public decimal Amount { get; set; }
    public DateTime PlacedAt { get; set; }
    public string UserName { get; set; }
}